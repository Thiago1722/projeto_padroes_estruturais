package org.example;

public class IngressoImpresso implements Entrega {
    public void entregarIngresso() {
        System.out.println("Ingresso impresso enviado pelos correios.");
    }
}