package org.example;

public class SistemaDeVenda {
    protected Pagamento pagamento;
    protected Entrega entrega;

    public SistemaDeVenda(Pagamento pagamento, Entrega entrega) {
        this.pagamento = pagamento;
        this.entrega = entrega;
    }

    public void venderIngresso(Evento evento) {
        System.out.println("Vendendo ingresso para o evento: " + evento.getNome());
        pagamento.processarPagamento();
        entrega.entregarIngresso();
    }
}