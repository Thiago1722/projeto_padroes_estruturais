package org.example;

public class PayPal implements Pagamento {
    public void processarPagamento() {
        System.out.println("Pagamento realizado via PayPal.");
    }
}


