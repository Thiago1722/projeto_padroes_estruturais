package org.example;

// Implementação: Métodos de pagamento
public interface Pagamento {
    void processarPagamento();
}
