package org.example;

// Evento (abstração que representa um tipo de evento)
public class Evento {
    private String nome;

    public Evento(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}