package org.example;

public class IngressoDigital implements Entrega {
    public void entregarIngresso() {
        System.out.println("Ingresso digital enviado por e-mail.");
    }
}