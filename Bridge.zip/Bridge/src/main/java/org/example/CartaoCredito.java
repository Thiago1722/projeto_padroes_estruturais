package org.example;

public class CartaoCredito implements Pagamento {
    public void processarPagamento() {
        System.out.println("Pagamento realizado via cartão de crédito.");
    }
}