import org.example.*;

// Uso do Bridge
public class Main {
    public static void main(String[] args) {
        Evento eventoConcerto = new Evento("Concerto de Rock");

        Pagamento pagamentoCartao = new CartaoCredito();
        Entrega entregaDigital = new IngressoDigital();

        SistemaDeVenda sistemaConcerto = new SistemaDeVenda(pagamentoCartao, entregaDigital);
        sistemaConcerto.venderIngresso(eventoConcerto);

        Evento eventoPalestra = new Evento("Palestra de Tecnologia");

        Pagamento pagamentoPayPal = new PayPal();
        Entrega entregaImpresso = new IngressoImpresso();

        SistemaDeVenda sistemaPalestra = new SistemaDeVenda(pagamentoPayPal, entregaImpresso);
        sistemaPalestra.venderIngresso(eventoPalestra);
    }
}