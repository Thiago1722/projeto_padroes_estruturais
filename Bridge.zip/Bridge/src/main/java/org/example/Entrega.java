package org.example;

public interface Entrega {
    void entregarIngresso();
}
