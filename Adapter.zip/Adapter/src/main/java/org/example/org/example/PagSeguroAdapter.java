import java.util.List;
import java.util.stream.Collectors;
import org.example.org.example.*;

public class PagSeguroAdapter {

    public static PagSeguroRequest adapt(PaymentRequest paymentRequest) {
        PagSeguroRequest request = new PagSeguroRequest.Builder()
                .setCheckoutId(paymentRequest.getId())
                .setReference(paymentRequest.getReferenceId())
                .setCustomer(adaptCustomer(paymentRequest.getCustomer()))
                .setItems(adaptItems(paymentRequest.getItems()))
                .setShipping(adaptShipping(paymentRequest.getShipping()))
                .setPaymentMethods(adaptPaymentMethods(paymentRequest.getPaymentMethods()))
                .build();
        return request;
    }

    private static PagSeguroRequest.Customer adaptCustomer(PaymentRequest.Customer customer) {
        PagSeguroRequest.Customer pagSeguroCustomer = new PagSeguroRequest.Customer();
        pagSeguroCustomer.setName(customer.getName());
        pagSeguroCustomer.setEmail(customer.getEmail());
        pagSeguroCustomer.setCpf(customer.getTaxId());
        pagSeguroCustomer.setPhone(adaptPhone(customer.getPhone()));
        return pagSeguroCustomer;
    }

    private static PagSeguroRequest.Phone adaptPhone(String phone) {
        PagSeguroRequest.Phone phoneObj = new PagSeguroRequest.Phone();
        phoneObj.setCountry("55");
        phoneObj.setNumber(phone);
        return phoneObj;
    }

    private static List<PagSeguroRequest.Item> adaptItems(List<PaymentRequest.Item> items) {
        return items.stream().map(item -> {
            PagSeguroRequest.Item pagSeguroItem = new PagSeguroRequest.Item();
            pagSeguroItem.setName(item.getName());
            pagSeguroItem.setQuantity(item.getQuantity());
            pagSeguroItem.setUnitPrice(item.getUnitPrice());
            return pagSeguroItem;
        }).collect(Collectors.toList());
    }

    private static PagSeguroRequest.Shipping adaptShipping(PaymentRequest.Shipping shipping) {
        PagSeguroRequest.Shipping pagSeguroShipping = new PagSeguroRequest.Shipping();
        pagSeguroShipping.setAddress(shipping.getAddress());
        pagSeguroShipping.setCity(shipping.getCity());
        pagSeguroShipping.setState(shipping.getState());
        pagSeguroShipping.setPostalCode(shipping.getPostalCode());
        return pagSeguroShipping;
    }

    private static List<PagSeguroRequest.PaymentMethod> adaptPaymentMethods(List<String> paymentMethods) {
        return paymentMethods.stream().map(method -> {
            PagSeguroRequest.PaymentMethod paymentMethod = new PagSeguroRequest.PaymentMethod();
            if ("credit_card".equalsIgnoreCase(method)) {
                paymentMethod.setType("CREDIT_CARD");
            } else if ("pix".equalsIgnoreCase(method)) {
                paymentMethod.setType("PIX");
            }
            return paymentMethod;
        }).collect(Collectors.toList());
    }
}
