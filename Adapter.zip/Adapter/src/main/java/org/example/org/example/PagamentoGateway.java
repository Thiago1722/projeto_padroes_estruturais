package org.example.org.example;

public interface PagamentoGateway {
    String realizarPedido(PaymentRequest pedidoRequisicao);
}

