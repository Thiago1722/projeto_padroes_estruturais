package org.example.org.example;

public class PaymentMethod {
    private String type;

    // Getters and Setters
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
