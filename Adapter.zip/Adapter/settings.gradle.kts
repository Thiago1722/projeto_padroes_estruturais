rootProject.name = "PadroesProjetoEstruturais"

