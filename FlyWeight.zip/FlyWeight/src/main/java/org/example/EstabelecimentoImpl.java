package org.example;

public class EstabelecimentoImpl {
    private Estabelecimento instance;
    private String nome;
    private Distancia distancia;

    public EstabelecimentoImpl(String tipo, Class <? extends Estabelecimento> tipoEstabelecimento){
        this.instance = EstabelecimentoFactoryImpl.getInstance().getEstabelecimento(tipo, tipoEstabelecimento);
    }

    public EstabelecimentoImpl(Builder builder) {
        this.nome = builder.nome;
        this.distancia = builder.distancia;
    }


    private static class Builder {
        private String nome;
        private Distancia distancia;

        public Builder nome (String nome){
            this.nome = nome;
            return this;
        }

        public Builder distancia (Distancia distancia){
            this.distancia = distancia;
            return this;
        }

        public EstabelecimentoImpl build(){
            return new EstabelecimentoImpl(this);
        }
    }

}
