package org.example;

public class Main {
    public static void main(String[] args) {
        EstabelecimentoFactory factory = EstabelecimentoFactoryImpl.getInstance();
        Estabelecimento escola = factory.getEstabelecimento("Escola", Escola.class);
        escola.setCategoria("Educação");
        System.out.println("Categoria da escola: " + escola.getCategoria());
        Distancia distancia = new Distancia(10.5);
        System.out.println("Distância: " + distancia.getDistancia());
    }
}
