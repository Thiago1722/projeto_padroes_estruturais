package org.example;

public class Escola implements Estabelecimento{
    private String categoria;

    @Override
    public String getCategoria() {
        return categoria;
    }

    @Override
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
