package org.example;

public interface EstabelecimentoFactory {
    Estabelecimento getEstabelecimento(String categoria, Class<? extends Estabelecimento> tipoEstabelecimento);
}

