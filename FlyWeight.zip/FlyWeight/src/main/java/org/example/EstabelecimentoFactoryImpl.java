package org.example;
import java.util.HashMap;
import java.util.Map;

public class EstabelecimentoFactoryImpl implements EstabelecimentoFactory{
    private static final EstabelecimentoFactoryImpl estabelecimentoFactory = new EstabelecimentoFactoryImpl();
    private EstabelecimentoFactoryImpl(){}
    private static final Map<String, Estabelecimento> estabelecimentos = new HashMap<>();

    public static EstabelecimentoFactoryImpl getInstance(){
        return estabelecimentoFactory;
    }
    public Estabelecimento getEstabelecimento(String tipo, Class <? extends Estabelecimento> tipoEstabelecimento){
        if(!estabelecimentos.containsKey(tipo)){
            try{
                Estabelecimento estabelecimento = tipoEstabelecimento.getDeclaredConstructor().newInstance();
                estabelecimentos.put(tipo, estabelecimento);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return estabelecimentos.get(tipo);
    }

}
