package org.example;

public interface Estabelecimento {
    String getCategoria();
    void setCategoria(String categoria);
}
