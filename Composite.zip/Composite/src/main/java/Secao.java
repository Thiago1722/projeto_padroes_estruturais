import java.util.ArrayList;
import java.util.List;

class Secao extends Ingresso {
    private String nome;
    private List<Ingresso> ingressos;

    public Secao(String nome) {
        this.nome = nome;
        this.ingressos = new ArrayList<>();
    }

    public void adicionarIngresso(Ingresso ingresso) {
        ingressos.add(ingresso);
    }

    @Override
    public void mostrarPreco() {
        System.out.println("Seção: " + nome);
        for (Ingresso ingresso : ingressos) {
            ingresso.mostrarPreco();
        }
    }
}