public class Main {
    public static void main(String[] args) {
        Ingresso ingressoCamarote = new IngressoIndividual("Camarote", 200);
        Ingresso ingressoPista = new IngressoIndividual("Pista", 100);
        Ingresso ingressoArquibancada = new IngressoIndividual("Arquibancada", 50);

        Secao secaoInferior = new Secao("Inferior");
        secaoInferior.adicionarIngresso(ingressoPista);
        secaoInferior.adicionarIngresso(ingressoArquibancada);

        Secao secaoSuperior = new Secao("Superior");
        secaoSuperior.adicionarIngresso(ingressoCamarote);

        Secao evento = new Secao("Evento de Rock");
        evento.adicionarIngresso(secaoInferior);
        evento.adicionarIngresso(secaoSuperior);

        // Exibindo os preços
        evento.mostrarPreco();
    }
}