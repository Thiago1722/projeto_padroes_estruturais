abstract class Ingresso {
    public abstract void mostrarPreco();
}