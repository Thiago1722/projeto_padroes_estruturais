class IngressoIndividual extends Ingresso {
    private String nome;
    private double preco;

    public IngressoIndividual(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    @Override
    public void mostrarPreco() {
        System.out.println("Ingresso " + nome + ": R$" + preco);
    }
}