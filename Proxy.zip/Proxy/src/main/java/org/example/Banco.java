package org.example;

public interface Banco {
    void realizarTransacao();
}
