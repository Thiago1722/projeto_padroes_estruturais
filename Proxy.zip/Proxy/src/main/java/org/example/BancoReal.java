package org.example;

public class BancoReal implements Banco{
    @Override
    public void realizarTransacao() {
        System.out.println("Transação realizada no banco real.");
    }
}
