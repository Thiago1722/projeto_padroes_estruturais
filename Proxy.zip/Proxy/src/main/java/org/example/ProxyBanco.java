package org.example;

public class ProxyBanco implements Banco {
    private BancoReal bancoReal;
    private String usuario;
    private String senha;

    public ProxyBanco(String usuario, String senha) {
        this.usuario = usuario;
        this.senha = senha;
    }

    private boolean estaAutenticado() {
        return "usuario123".equals(usuario) && "senha123".equals(senha);
    }

    @Override
    public void realizarTransacao() {
        if (estaAutenticado()) {
            if (bancoReal == null) {
                bancoReal = new BancoReal();
            }
            bancoReal.realizarTransacao();
        } else {
            System.out.println("Autenticação falhou. Transação não realizada.");
        }
    }
}
