package org.example;
public class Main {
    public static void main(String[] args) {
        // Simulação com credenciais corretas
        Banco bancoAutenticado = new ProxyBanco("usuario123", "senha123");
        bancoAutenticado.realizarTransacao(); // Deverá passar pela autenticação e realizar a transação

        System.out.println();

        // Simulação com credenciais incorretas
        Banco bancoNaoAutenticado = new ProxyBanco("usuario123", "senhaErrada");
        bancoNaoAutenticado.realizarTransacao(); // Não permitirá a transação devido à falha na autenticação
    }
}
